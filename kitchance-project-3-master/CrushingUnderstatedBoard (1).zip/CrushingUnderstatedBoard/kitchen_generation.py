import requests
import base64
import tkinter as tk
from tkinter import filedialog
import webbrowser
import time
import json
from transformers import pipeline
from sentence_transformers import SentenceTransformer, util

# --- Modularized Rule Engine Function ---
def detect_styles_and_rules(summary, window_positions):
    embedder = SentenceTransformer('all-MiniLM-L6-v2')

    # Design Styles
    design_styles = {
        "modern": "modern design with clean lines, minimal clutter, and contemporary aesthetics",
        "eco-friendly": "sustainable and eco-friendly materials with a focus on natural elements and green design principles",
        "rustic": "rustic style with farmhouse elements like reclaimed wood, stone textures, and warm tones",
        "minimalist": "minimalist design focused on simplicity, decluttered spaces, and monochrome palettes",
        "industrial": "industrial design featuring raw materials like concrete, metal beams, exposed brick, and an urban loft vibe",
        "luxury": "luxurious and upscale design with premium materials like marble, gold accents, and high-end appliances",
        "scandinavian": "scandinavian design with light colors, natural wood, cozy textures, and a functional, airy look",
        "bohemian": "bohemian style with eclectic patterns, vibrant colors, layered textiles, and a casual, relaxed atmosphere",
        "traditional": "traditional design with classic furniture, detailed woodwork, rich color palettes, and symmetrical layouts",
        "coastal": "coastal design with light, breezy tones, nautical elements, and a relaxed beach-house feel",
        "mid-century modern": "mid-century modern style with retro furniture, bold geometric shapes, and organic curves",
        "transitional": "transitional design blending traditional and contemporary elements for a timeless and balanced aesthetic",
        "art deco": "art deco style with bold geometric patterns, metallic finishes, and opulent, glamorous vibes"
    }

    # Mood Descriptors
    moods = {
        "airy": "An open and airy atmosphere with plenty of breathing room",
        "cozy": "A warm and inviting space with soft textures and intimate lighting",
        "formal": "A formal and sophisticated space with structured layout and upscale finishes",
        "casual": "A laid-back and comfortable setting with informal design choices"
    }

    # Persona Descriptors
    personas = {
        "family": "A family-oriented kitchen designed for multiple users and kid-friendly functionality",
        "chef": "A chef's kitchen with professional-grade appliances and efficient workflow",
        "entertainer": "A kitchen designed for hosting, featuring open social areas and serving spaces"
    }

    summary_embedding = embedder.encode(summary, convert_to_tensor=True)
    style_embeddings = {style: embedder.encode(desc, convert_to_tensor=True) for style, desc in design_styles.items()}
    mood_embeddings = {mood: embedder.encode(desc, convert_to_tensor=True) for mood, desc in moods.items()}
    persona_embeddings = {persona: embedder.encode(desc, convert_to_tensor=True) for persona, desc in personas.items()}

    # Style Matching
    similarities = []
    for style, style_embedding in style_embeddings.items():
        similarity = util.pytorch_cos_sim(summary_embedding, style_embedding).item()
        similarities.append((style, similarity))
        print(f"Similarity to {style}: {similarity:.2f}")

    similarities = sorted(similarities, key=lambda x: x[1], reverse=True)
    top_style, top_score = similarities[0]
    second_style, second_score = similarities[1]

    weighted_styles = [(top_style, 0.7), (second_style, 0.3)] if top_score - second_score < 0.05 else [(top_style, 1.0)]

    # Mood Matching
    mood = max(moods.keys(), key=lambda m: util.pytorch_cos_sim(summary_embedding, mood_embeddings[m]).item())
    print(f"Detected Mood: {mood}")

    # Persona Matching
    persona = max(personas.keys(), key=lambda p: util.pytorch_cos_sim(summary_embedding, persona_embeddings[p]).item())
    print(f"Detected Persona: {persona}")

    RULES = []

    for style, weight in weighted_styles:
        if style == "modern":
            RULES.append(f"({int(weight * 100)}%) Use modern design principles with clean lines and contemporary finishes.")
        elif style == "eco-friendly":
            RULES.append(f"({int(weight * 100)}%) Incorporate sustainable and eco-friendly materials such as reclaimed wood and energy-efficient appliances.")
        elif style == "rustic":
            RULES.append(f"({int(weight * 100)}%) Add rustic elements like exposed wood beams, natural textures, and warm color palettes.")
        elif style == "minimalist":
            RULES.append(f"({int(weight * 100)}%) Emphasize minimalist design with decluttered surfaces, open spaces, and neutral tones.")
        elif style == "industrial":
            RULES.append(f"({int(weight * 100)}%) Integrate industrial elements like exposed pipes, concrete finishes, and metal accents.")
        elif style == "luxury":
            RULES.append(f"({int(weight * 100)}%) Ensure a luxurious atmosphere with marble countertops, high-end materials, and premium appliances.")
        elif style == "scandinavian":
            RULES.append(f"({int(weight * 100)}%) Incorporate Scandinavian design with light color palettes, natural wood, and cozy, functional spaces.")
        elif style == "bohemian":
            RULES.append(f"({int(weight * 100)}%) Introduce bohemian style with eclectic patterns, vibrant textiles, and relaxed, layered décor.")
        elif style == "traditional":
            RULES.append(f"({int(weight * 100)}%) Use traditional design elements like classic woodwork, rich tones, and symmetrical layouts.")
        elif style == "coastal":
            RULES.append(f"({int(weight * 100)}%) Incorporate coastal aesthetics with light, breezy colors, nautical accents, and relaxed beach vibes.")
        elif style == "mid-century modern":
            RULES.append(f"({int(weight * 100)}%) Add mid-century modern features like retro furniture, geometric shapes, and organic curves.")
        elif style == "transitional":
            RULES.append(f"({int(weight * 100)}%) Blend traditional and modern elements to create a timeless and balanced transitional design.")
        elif style == "art deco":
            RULES.append(f"({int(weight * 100)}%) Include art deco features like bold geometric patterns, metallic finishes, and a touch of opulence.")

    # Mood & Persona Injection
    RULES.append(f"Reflect a {mood} atmosphere throughout the space.")
    RULES.append(f"Design the kitchen with a {persona} focus.")

    if window_positions:
        RULES.insert(0, "Preserve the detected window positions exactly as they are; do not alter, move, or resize them.")
        RULES.insert(1, "Do not add any new physical structures such as windows, doors, walls, or beams that are not present in the provided image.")
    else:
        RULES.insert(0, "No window positions detected. Do not add new windows, doors, or other physical structures unless explicitly specified by the customer.")

    return RULES

# --- Fetch Latest Transcript from KitChance Backend ---
url = "http://0.0.0.0:3000/latest-transcript"


try:
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        latest_transcript = data.get("transcript", "")
    else:
        print(f"Error fetching transcript: {response.status_code}")
        latest_transcript = ""
except Exception as e:
    print(f"Exception fetching transcript: {e}")
    latest_transcript = ""

if latest_transcript.strip():
    summarizer = pipeline("summarization", model="facebook/bart-large-cnn")
    summary = summarizer(latest_transcript, max_length=150, min_length=50, do_sample=False)[0]['summary_text']
    print("Generated Prompt from Transcript:", summary)
else:
    print("No recent transcript available. Using default description.")
    summary = "A modern and functional kitchen with ample lighting and sleek cabinetry."

# --- Image Upload and Processing ---
ROBOFLOW_API_KEY = "N3iXKoKbnEK5dv7pgEN7"
MODEL_ID = "doors-and-windows-ljqti"
MODEL_VERSION = "2"
ROBOFLOW_API_URL = f"https://detect.roboflow.com/{MODEL_ID}/{MODEL_VERSION}?api_key={ROBOFLOW_API_KEY}"

def select_image():
    root = tk.Tk()
    root.withdraw()
    root.call('wm', 'attributes', '.', '-topmost', True)
    file_path = filedialog.askopenfilename(
        title="Select an Image",
        filetypes=[("Image Files", "*.jpg *.jpeg *.png *.bmp *.gif")]
    )
    return file_path

image_path = select_image()
if not image_path:
    print("No image selected. Exiting...")
    exit()

print(f"Selected Image: {image_path}")

with open(image_path, "rb") as image_file:
    image_data = image_file.read()

response = requests.post(
    ROBOFLOW_API_URL,
    files={"file": image_data},
)

if response.status_code != 200:
    print(f"Error: {response.status_code}, {response.text}")
    exit()

detections = response.json()
print("Roboflow Predictions:", json.dumps(detections, indent=2))

window_positions = []
for prediction in detections.get("predictions", []):
    if "window" in prediction["class"].lower():
        x, y, width, height = prediction["x"], prediction["y"], prediction["width"], prediction["height"]
        window_positions.append(f"Window at ({x}, {y}) with size {width}x{height}")

# Apply Modular Rule Engine
RULES = detect_styles_and_rules(summary, window_positions)

window_info = " ".join(window_positions) if window_positions else "No specific window positions detected."

prompt = f"""
### Customer Preferences (Extracted Summary):
{summary}

### Detected Features:
{window_info}

### Design Guidelines:
{chr(10).join('- ' + rule for rule in RULES)}

### Notes:
Strictly respect the existing structure of the room based on the provided image. No structural changes such as moving or adding windows, doors, or walls are allowed. Only focus on layout optimization, style adaptation, and non-structural modifications.
"""

print("\n🧠 Semantic Dynamic Prompt:", prompt.strip())

ROOMGPT_API_TOKEN = "r8_5Xo3Jz4U92OfKV81vjdb41vSO5LMsYD1NNwaL"
ROOMGPT_API_URL = "https://api.replicate.com/v1/predictions"

with open(image_path, "rb") as image_file:
    base64_image = base64.b64encode(image_file.read()).decode("utf-8")

input_data = {
    "seed": 20,
    "image": f"data:image/jpeg;base64,{base64_image}",
    "prompt": prompt,
    "structure": "scribble",
    "image_resolution": 512
}

headers = {
    "Authorization": f"Token {ROOMGPT_API_TOKEN}",
    "Content-Type": "application/json",
}

data = {
    "version": "795433b19458d0f4fa172a7ccf93178d2adb1cb8ab2ad6c8fdc33fdbcd49f477",
    "input": input_data,
}

response = requests.post(ROOMGPT_API_URL, headers=headers, json=data)

if response.status_code == 201:
    prediction = response.json()
    status_url = prediction['urls']['get']
    print("Prediction started! Check status at:", status_url)

    status_headers = {
        "Authorization": f"Token {ROOMGPT_API_TOKEN}"
    }

    while True:
        status_response = requests.get(status_url, headers=status_headers)
        if status_response.status_code == 200:
            result = status_response.json()
            if result['status'] == 'succeeded' and 'urls' in result and 'stream' in result['urls']:
                stream_url = result['urls']['stream']
                print(f"Opening RoomGPT Result: {stream_url}")
                webbrowser.open(stream_url)
                break
            elif result['status'] in ['failed', 'canceled']:
                print("Prediction failed or was canceled.")
                break
            else:
                print("Processing... Waiting for output...")
                time.sleep(5)
        else:
            print(f"Error {status_response.status_code}: {status_response.json().get('detail', 'No detail provided')}")
            break
else:
    print(f"Error {response.status_code}: {response.json().get('detail', 'No detail provided')}")
